Action()
{

	lr_start_transaction("open_homepage");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_set_sockets_option("TLS_SNI", "0");

	web_set_user("jSmith1", 
		lr_unmask("647cf70586646a1e247cfa00ab"), 
		"www.advantageonlineshopping.com:443");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("A-IM", 
		"x-bm,gzip");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=114", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_add_cookie("_gid=GA1.2.904682873.1685878907; DOMAIN=www.advantageonlineshopping.com");

	web_add_cookie("_ga=GA1.2.401783448.1685878901; DOMAIN=www.advantageonlineshopping.com");

	web_add_cookie("userCart=%7B%22userId%22%3A-1%2C%22productsInCart%22%3A%5B%5D%7D; DOMAIN=www.advantageonlineshopping.com");

	web_add_cookie("_ga_TBPYED8WSW=GS1.1.1685910255.6.1.1685911143.0.0.0; DOMAIN=www.advantageonlineshopping.com");

	web_add_cookie("_ga=GA1.1.401783448.1685878901; DOMAIN=www.advantageonlineshopping.com");

	web_add_cookie("_ga_TBPYED8WSW=GS1.1.1685910255.6.1.1685911173.0.0.0; DOMAIN=www.advantageonlineshopping.com");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Not.A/Brand\";v=\"8\", \"Chromium\";v=\"114\", \"Google Chrome\";v=\"114\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("www.advantageonlineshopping.com", 
		"URL=https://www.advantageonlineshopping.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/vendor/requirejs/require.js", ENDITEM, 
		"Url=/main.min.js", ENDITEM, 
		"Url=/services.properties", ENDITEM, 
		"Url=/app/tempFiles/popularProducts.json", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_url("ALL", 
		"URL=https://www.advantageonlineshopping.com/catalog/api/v1/DemoAppConfig/parameters/by_tool/ALL", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/css/fonts/roboto_regular_macroman/Roboto-Regular-webfont.woff", "Referer=https://www.advantageonlineshopping.com/css/main.min.css", ENDITEM, 
		"Url=/css/fonts/roboto_light_macroman/Roboto-Light-webfont.woff", "Referer=https://www.advantageonlineshopping.com/css/main.min.css", ENDITEM, 
		"Url=/css/fonts/roboto_medium_macroman/Roboto-Medium-webfont.woff", "Referer=https://www.advantageonlineshopping.com/css/main.min.css", ENDITEM, 
		LAST);

	web_add_cookie("_gat=1; DOMAIN=www.advantageonlineshopping.com");

	web_add_header("Origin", 
		"https://www.advantageonlineshopping.com");

	web_add_header("SOAPAction", 
		"com.advantage.online.store.accountserviceGetAccountConfigurationRequest");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("GetAccountConfigurationRequest", 
		"URL=https://www.advantageonlineshopping.com/accountservice/ws/GetAccountConfigurationRequest", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"EncType=text/xml; charset=UTF-8", 
		"Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><soap:Body><GetAccountConfigurationRequest xmlns=\"com.advantage.online.store.accountservice\"></GetAccountConfigurationRequest></soap:Body></soap:Envelope>", 
		LAST);

	web_url("categories", 
		"URL=https://www.advantageonlineshopping.com/catalog/api/v1/categories", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	web_url("search", 
		"URL=https://www.advantageonlineshopping.com/catalog/api/v1/deals/search?dealOfTheDay=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	web_url("home-page.html", 
		"URL=https://www.advantageonlineshopping.com/app/views/home-page.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/css/fonts/roboto_bold_macroman/Roboto-Bold-webfont.woff", "Referer=https://www.advantageonlineshopping.com/css/main.min.css", ENDITEM, 
		"Url=/css/fonts/roboto_thin_macroman/Roboto-Thin-webfont.woff", "Referer=https://www.advantageonlineshopping.com/css/main.min.css", ENDITEM, 
		LAST);

	lr_end_transaction("open_homepage",LR_AUTO);

	lr_start_transaction("login");

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("X-Goog-Update-AppId", 
		"ihnlcenocehgdaegdmhbidjhnhdchfmm,gcmjkmgdlgnkkcocmoeiminaijmmjnii,lmelglejhemejginpboagddgdfbepgmp,neifaoindggfcjicffkgpmnlppeffabd,khaoiebndkojlmppeemjhbpbandiljpe,oimompecagnajdejgnnjijobebaeigek,giekcmmlnklenlaomppkphknjmnnpneh,hnimpnehoodheedghdeeijklkeaacbdc,obedbbhbpmojnkanicioggnmelmoomoc,laoigpblnllgcgjnjnllmfolckpjlhki,llkgjffcdpffmhiakmfcdcblohccpfmo,ehgidpndbllacpjalkiimkbadgjfnnmc,jflookgnkcckhobaglndicnbbgbonegd,ggkkehgbnfjpeggfpleeakpidbkibbmn,efniojlnjndmcbiieegkicadnoecjjef,"
		"imefjhfbkmcmebodilednhmaccmincoa,ojhpjlocmbogdgmfpkhlaaeamibhnphh,hfnkpimlhhgieaddgfemjhofmfblmnib,jamhcnnkihinmdlkakkaopbjbbcngflc,eeigpngbgcognadeebkilcpcaedhellh,gonpemdgkjcecdgbnaabipppbmgfggbe");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chrome-114.0.5735.91");

	lr_think_time(31);

	web_custom_request("json", 
		"URL=http://update.googleapis.com/service/update2/json?cup2key=13:Rik01s8erDw-u3wFzog55hqMDxWBnlo8voMx0Mwptc0&cup2hreq=a34c03261e53173d645eb5bf8528a6b09e60e43a76bf81b66de8d623c1e1c546", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5998,\"lang\":\"ru\",\"ping\":{\"ping_freshness\":\"{50e268f4-c680-4807-9573-725404f72b2d}\",\"rd\":5998},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GGLS\",\"cohort\":\"1:bm1:\",\"cohortname\":\"M54AndUp\",\"enabled\":true,\""
		"installdate\":5998,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.1482735f1e6f6a7151f8bbe11abf8e6ff034bcf0466ed44f804e8a819243a7ca\"}]},\"ping\":{\"ping_freshness\":\"{def6467b-d2e3-44a2-88ae-2702d022376a}\",\"rd\":5998},\"updatecheck\":{},\"version\":\"9.45.0\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"GGLS\",\"cohort\":\"1:lwl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5998,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\""
		"1.b5cd54a88dcc5c066af2a939c533ecfb73019547dc6d069a66cae33f255b8746\"}]},\"ping\":{\"ping_freshness\":\"{a278e8a8-61f6-4dfc-96b5-dc643765c390}\",\"rd\":5998},\"updatecheck\":{},\"version\":\"394\"},{\"appid\":\"neifaoindggfcjicffkgpmnlppeffabd\",\"brand\":\"GGLS\",\"cohort\":\"1:1299:\",\"cohortname\":\"Windows (102+, canary/dev/beta/stable)\",\"enabled\":true,\"installdate\":5998,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\""
		"1.faef821457e35b44f92e45ae9c7c4424eb39c8f8bd02562a358bd2c5542570b9\"}]},\"ping\":{\"ping_freshness\":\"{048920c5-f184-4251-b37a-6ad46e3185c8}\",\"rd\":5998},\"updatecheck\":{},\"version\":\"1.0.2512.0\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GGLS\",\"cohort\":\"1:cux:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5998,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.4d4a9ece68f12d31fb4ebe458e7cbbce6bd27a5d363bce3344b1f4b5c6b024b4\"}]},\"ping\":{\""
		"ping_freshness\":\"{d4ff9fac-9de1-4c99-b68d-38103923bfdf}\",\"rd\":5998},\"tag\":\"default\",\"updatecheck\":{},\"version\":\"58\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GGLS\",\"cohort\":\"1:1n4r:\",\"cohortname\":\"4.10.2652.1 for 113+\",\"enabled\":true,\"installdate\":5998,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.37a3ce45e4db03ee45245937e81291fc7f3c8faf62e4f05ad48f544a783542c3\"}]},\"ping\":{\"ping_freshness\":\"{0a08d608-58c7-4e91-9667-215ebd8e06f5}\",\"rd"
		"\":5998},\"updatecheck\":{},\"version\":\"4.10.2652.1\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GGLS\",\"cohort\":\"1:j5l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5998,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{3e1b9af1-2ee1-461b-8f13-dd0f6b0799bf}\",\"rd\":5998},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc"
		"\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5998,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.6f6bc93dcd62dc251850d2ff458fda96083ceb7fbe8eeb11248b8485ef2aea23\"}]},\"ping\":{\"ping_freshness\":\"{c9348d1e-8da1-40f6-8be7-5f8deda98c35}\",\"rd\":5998},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"accept_locale\":\"RU500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GGLS\",\"cohort\":\"1:s6f:\",\"cohortname\":\"Auto\",\"enabled\":true,\""
		"installdate\":5998,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.17c79175d6a9b0809c465d3636064510cf1997abb09b33c8c29fd6544cc2c9cb\"}]},\"ping\":{\"ping_freshness\":\"{97fc19d0-6c69-4f5b-b364-26d20a2f700f}\",\"rd\":5998},\"updatecheck\":{},\"version\":\"20230524.536550353.14\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"GGLS\",\"cohort\":\"1:10zr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5998,\"lang\":\"ru\",\"ping\":{\"ping_freshness\":\""
		"{ff03854a-667a-4105-b8a7-aeebdd455ed1}\",\"rd\":5998},\"updatecheck\":{},\"version\":\"1.0.7.1652906823\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5998,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.ab8d70a60ce0fba1355fad4edab88fd4d1bccc566b230998180183d1d776992b\"}]},\"ping\":{\"ping_freshness\":\"{fdd8506e-7e5a-4afd-8eb6-29558b5dd0b8}\",\"rd\":5998},\"updatecheck\":{},\"version\":\"1.0.0.13\"},{\"appid\":\""
		"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GGLS\",\"cohort\":\"1:ofl:\",\"cohortname\":\"stable64\",\"enabled\":true,\"installdate\":5998,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{b45920bf-d7e4-43fa-82da-40f0103db360}\",\"rd\":5998},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GGLS\",\"cohort\":\"1:s7x:\",\"cohortname\""
		":\"Auto\",\"enabled\":true,\"installdate\":5998,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.a9c3fb119d9e91ee3cd6c5bb93122a46f8e722e1986ee209d5747c327d238f87\"}]},\"ping\":{\"ping_freshness\":\"{cba7ef94-33f5-40c0-9a05-824e3be00461}\",\"rd\":5998},\"updatecheck\":{},\"version\":\"2962\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GGLS\",\"cohort\":\"1:ut9/1a0f:\",\"cohortname\":\"108-and-above-all-users\",\"enabled\":true,\"installdate\":5998,\"lang\":\"ru\",\"packages\""
		":{\"package\":[{\"fp\":\"1.ed2f4d0fa9d2f99837719f80e3990498314290c6a294a72296ddcada784dd278\"}]},\"ping\":{\"ping_freshness\":\"{93bd171d-f476-46cb-8e8e-28793900a0de}\",\"rd\":5998},\"updatecheck\":{},\"version\":\"2022.12.16.779\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"GGLS\",\"cohort\":\"1:18ql:\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":5998,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\""
		"1.f482550ed2921321aa4692efc86ff21e35dc41119d2c468e40fca36f6b31e460\"}]},\"ping\":{\"ping_freshness\":\"{65379012-4e71-4001-a213-d6c073802f81}\",\"rd\":5998},\"updatecheck\":{},\"version\":\"605\"},{\"appid\":\"imefjhfbkmcmebodilednhmaccmincoa\",\"brand\":\"GGLS\",\"cohort\":\"1:1iaf:\",\"cohortname\":\"windows_flatbuffers\",\"enabled\":true,\"installdate\":5998,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.3525bd7c472e4c85cadf1b8d0992ca8303b9e630831e4530e54a14a70f213a11\"}]},\"ping\":{\""
		"ping_freshness\":\"{76fb59bd-84fa-4d3a-9d39-556e376bb488}\",\"rd\":5998},\"tag\":\"desktop_1_flatbuffer\",\"updatecheck\":{},\"version\":\"30.2\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"GGLS\",\"cohort\":\"1:w0x:\",\"cohortname\":\"All users\",\"enabled\":true,\"installdate\":5998,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\"ping\":{\"ping_freshness\":\"{4a22c89b-90e1-462e-9a6f-0f7eb5e945ef}\",\""
		"rd\":5998},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GGLS\",\"cohort\":\"1:jcl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5998,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.83d989c2a4e6c4df8052b9f429547eb638f754dc68f4088d5ecc1b8de26cd88d\"}]},\"ping\":{\"ping_freshness\":\"{96c78ef3-165e-4339-a0de-9e9007bac8b8}\",\"rd\":5998},\"updatecheck\":{},\"version\":\"8034\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\""
		"brand\":\"GGLS\",\"cohort\":\"1:wvr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5998,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.9d5a226ba8b8a3a75d6c00897c0429fd5ad802f0851ff7dfca6bbfc4fe299f2f\"}]},\"ping\":{\"ping_freshness\":\"{672d8d66-6343-4d3c-a6d6-fe3c39570701}\",\"rd\":5998},\"updatecheck\":{},\"version\":\"116.0.5812.0\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"GGLS\",\"cohort\":\"1:w59:\",\"cohortname\":\"Auto\",\"enabled\":true,\""
		"installdate\":5998,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{08bcb34e-89d9-4863-b2dc-f036587df48e}\",\"rd\":5998},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"},{\"_internal_experimental_sets\":\"false\",\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"GGLS\",\"cohort\":\"1:z1x:\",\"cohortname\":\"General release\",\"enabled\":true,\"installdate\":5998,\"lang\":\"ru\","
		"\"packages\":{\"package\":[{\"fp\":\"1.c4137d1ea479cdf5cbe29e09e4cef452fba88fecb53cd82414432cd3825329f8\"}]},\"ping\":{\"ping_freshness\":\"{0b5352b5-2b60-4424-a54e-61512e9d4d11}\",\"rd\":5998},\"updatecheck\":{},\"version\":\"2023.5.17.1\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":16,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\""
		"platform\":\"Windows\",\"version\":\"10.0.19045.2965\"},\"prodversion\":\"114.0.5735.91\",\"protocol\":\"3.1\",\"requestid\":\"{ee1cf1f9-488e-4abc-9aab-34510981ea95}\",\"sessionid\":\"{25233f74-737e-4c2d-bb5d-c4ade5d07e46}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.36.242\"},\"updaterversion\":\"114.0.5735.91\"}}", 
		LAST);

	web_add_header("Origin", 
		"https://www.advantageonlineshopping.com");

	web_add_header("SOAPAction", 
		"com.advantage.online.store.accountserviceAccountLoginRequest");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("sec-ch-ua", 
		"\"Not.A/Brand\";v=\"8\", \"Chromium\";v=\"114\", \"Google Chrome\";v=\"114\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(4);

	web_custom_request("AccountLoginRequest", 
		"URL=https://www.advantageonlineshopping.com/accountservice/ws/AccountLoginRequest", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"EncType=text/xml; charset=UTF-8", 
		"Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><soap:Body><AccountLoginRequest xmlns=\"com.advantage.online.store.accountservice\"><email></email><loginPassword>Pa$$word1</loginPassword><loginUser>jSmith1</loginUser></AccountLoginRequest></soap:Body></soap:Envelope>", 
		LAST);

	web_set_sockets_option("INITIAL_AUTH", "BASIC");

	web_url("603366726", 
		"URL=https://www.advantageonlineshopping.com/order/api/v1/carts/603366726", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("login",LR_AUTO);

	lr_think_time(17);

	lr_start_transaction("go_to_speakers");

	web_url("products", 
		"URL=https://www.advantageonlineshopping.com/catalog/api/v1/categories/4/products", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	web_url("attributes", 
		"URL=https://www.advantageonlineshopping.com/catalog/api/v1/categories/attributes", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);

	web_url("category-page.html", 
		"URL=https://www.advantageonlineshopping.com/app/views/category-page.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://safebrowsing.googleapis.com/v4/fullHashes_find?$req="
		"Ch0KDGdvb2dsZWNocm9tZRINMTE0LjAuNTczNS45MRIbCg0IBRAGGAEiAzAwMTABEJP2EBoCGASHC9q0EhsKDQgBEAYYASIDMDAxMAEQ27QMGgIYBGpD8a4SGwoNCAcQBhgBIgMwMDEwARCC-gwaAhgEm0Js-hIZCg0IARAGGAEiAzAwMTADEBQaAhgEH2nYQBIaCg0IARAIGAEiAzAwMTAEEKkzGgIYBKs2exkSGgoNCA8QBhgBIgMwMDEwARCXeRoCGARy98KlEhkKDQgKEAgYASIDMDAxMAEQBxoCGAS_dbvkEhkKDQgJEAYYASIDMDAxMAEQIBoCGASYcv_5EhoKDQgIEAYYASIDMDAxMAEQ-hIaAhgEKXPhhxIbCg0IDRAGGAEiAzAwMTABELLrARoCGARMeFdkEhsKDQgDEAYYASIDMDAxMAEQyqoMGgIYBFhZn2MSGwoNCA4QBhgBIgMwMDEwARDJhAcaAhgERolNABIaCg0IEB"
		"AGGAEiAzAwMTABEO8ZGgIYBATOByEaKggBCAMIBQgGCAcICAgJCAoIDQgOCA8IEBABEAgaBgoELm_LdiABIAMgBA==&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("go_to_speakers",LR_AUTO);

	lr_think_time(20);

	lr_start_transaction("go_to_product");

	web_url("all_data", 
		"URL=https://www.advantageonlineshopping.com/catalog/api/v1/categories/all_data", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		LAST);

	web_url("20", 
		"URL=https://www.advantageonlineshopping.com/catalog/api/v1/products/20", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		LAST);

	web_url("product-page.html", 
		"URL=https://www.advantageonlineshopping.com/app/views/product-page.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("go_to_product",LR_AUTO);

	lr_start_transaction("add_to_cart");

	web_add_auto_header("Origin", 
		"https://www.advantageonlineshopping.com");

	lr_think_time(15);

	web_submit_data("414141", 
		"Action=https://www.advantageonlineshopping.com/order/api/v1/carts/603366726/product/20/color/414141?quantity=1", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=sessionId", "Value=39A72D5021166AD8CE4B66A431D142EB", ENDITEM, 
		LAST);

	lr_end_transaction("add_to_cart",LR_AUTO);

	lr_think_time(20);

	lr_start_transaction("remove_from_cart");

	web_custom_request("414141_2", 
		"URL=https://www.advantageonlineshopping.com/order/api/v1/carts/603366726/product/20/color/414141", 
		"Method=DELETE", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("remove_from_cart",LR_AUTO);

	return 0;
}